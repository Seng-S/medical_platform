<?php

    interface SpecializationManager {
        public function getSpecializations();
    }

?>