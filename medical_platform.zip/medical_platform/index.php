<?php 

    header('Location: http://localhost/medical_platform/pages/home.php');
    
?>